using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PlataformaEficienciaEnergetica.Views.Predios
{
    public class CriarModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
