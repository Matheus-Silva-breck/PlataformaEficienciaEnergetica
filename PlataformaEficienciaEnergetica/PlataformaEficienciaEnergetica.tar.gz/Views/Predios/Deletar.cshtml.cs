using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PlataformaEficienciaEnergetica.Views.Predios
{
    public class DeletarModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
