using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PlataformaEficienciaEnergetica.Views.Predios
{
    public class EditarModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
